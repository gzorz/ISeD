def classFactory(iface):
    from .MK import MK
    return MK(iface)
